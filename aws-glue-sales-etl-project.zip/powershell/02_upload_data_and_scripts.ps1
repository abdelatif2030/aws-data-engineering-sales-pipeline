# =============================================================================
# AWS Glue Sales ETL Project - Step 2: Upload Data & Glue Scripts
# =============================================================================
# Uploads sample CSV data and PySpark ETL script to S3.
# Run after: 01_setup_infrastructure.ps1
# =============================================================================

# Load saved config
$config = Get-Content ".\project-config.json" | ConvertFrom-Json
$BUCKET_RAW     = $config.BUCKET_RAW
$BUCKET_SCRIPTS = $config.BUCKET_SCRIPTS
$AWS_REGION     = $config.AWS_REGION

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Step 2: Upload Data & Scripts to S3" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan

# --------------------------------------------------------------------------
# STEP 1: Upload sample CSV data (partitioned by year/month)
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[1/3] Uploading sample sales CSV data..." -ForegroundColor Yellow

$dataFiles = @(
    @{ LocalPath = "..\sample-data\sales_2024_q1.csv"; S3Key = "sales/year=2024/month=01/sales_2024_q1.csv" }
)

foreach ($file in $dataFiles) {
    if (Test-Path $file.LocalPath) {
        aws s3 cp $file.LocalPath "s3://$BUCKET_RAW/$($file.S3Key)" | Out-Null
        Write-Host "  Uploaded: $($file.S3Key)" -ForegroundColor Green
    } else {
        Write-Warning "  File not found: $($file.LocalPath) — skipping"
    }
}

# --------------------------------------------------------------------------
# STEP 2: Upload the PySpark ETL script
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[2/3] Uploading PySpark ETL job script..." -ForegroundColor Yellow

$etlScript = "..\glue-scripts\sales_etl_job.py"
if (Test-Path $etlScript) {
    aws s3 cp $etlScript "s3://$BUCKET_SCRIPTS/glue-scripts/sales_etl_job.py" | Out-Null
    Write-Host "  Script uploaded: s3://$BUCKET_SCRIPTS/glue-scripts/sales_etl_job.py" -ForegroundColor Green
} else {
    Write-Warning "  ETL script not found at $etlScript"
}

# --------------------------------------------------------------------------
# STEP 3: Verify uploads
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[3/3] Verifying S3 uploads..." -ForegroundColor Yellow

Write-Host "  Raw bucket contents:"
aws s3 ls "s3://$BUCKET_RAW/" --recursive --human-readable | ForEach-Object {
    Write-Host "    $_" -ForegroundColor DarkGreen
}

Write-Host "  Scripts bucket contents:"
aws s3 ls "s3://$BUCKET_SCRIPTS/" --recursive --human-readable | ForEach-Object {
    Write-Host "    $_" -ForegroundColor DarkGreen
}

Write-Host ""
Write-Host "================================================" -ForegroundColor Green
Write-Host "  Data & Scripts Upload COMPLETE" -ForegroundColor Green
Write-Host "================================================" -ForegroundColor Green
Write-Host "Next step: Run  .\03_create_crawler.ps1"
Write-Host ""
