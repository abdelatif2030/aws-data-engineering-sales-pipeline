# =============================================================================
# AWS Glue Sales ETL Project - Step 4: Create & Run Glue ETL Job
# =============================================================================
# Creates the Glue Job with PySpark script and runs it.
# Free-tier safe: G.1X worker type, 2 DPUs, job bookmarks enabled.
# Run after: 03_create_crawler.ps1
# =============================================================================

$config          = Get-Content ".\project-config.json" | ConvertFrom-Json
$BUCKET_RAW      = $config.BUCKET_RAW
$BUCKET_PROCESSED= $config.BUCKET_PROCESSED
$BUCKET_SCRIPTS  = $config.BUCKET_SCRIPTS
$ROLE_ARN        = $config.ROLE_ARN
$GLUE_DB         = $config.GLUE_DB
$AWS_REGION      = $config.AWS_REGION

$JOB_NAME        = "sales_etl_job"
$SCRIPT_S3       = "s3://$BUCKET_SCRIPTS/glue-scripts/sales_etl_job.py"
$TABLE_NAME      = "sales"   # Name assigned by the crawler (matches folder name)

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Step 4: Create & Run Glue ETL Job" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan

# --------------------------------------------------------------------------
# CREATE THE GLUE JOB
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[1/3] Creating Glue ETL Job: $JOB_NAME ..." -ForegroundColor Yellow

# Check if already exists and delete
$existing = aws glue get-job --job-name $JOB_NAME --region $AWS_REGION 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "  Job already exists, deleting and recreating..."
    aws glue delete-job --job-name $JOB_NAME --region $AWS_REGION | Out-Null
    Start-Sleep -Seconds 3
}

# Build default arguments as JSON
$defaultArgs = @{
    "--job-bookmark-option"         = "job-bookmark-enable"   # Prevents reprocessing
    "--enable-metrics"              = "true"                  # CloudWatch metrics
    "--enable-continuous-cloudwatch-log" = "true"            # Live log streaming
    "--enable-spark-ui"             = "false"                 # Disable to save cost
    "--TempDir"                     = "s3://$BUCKET_SCRIPTS/temp/"
    "--raw_bucket"                  = $BUCKET_RAW
    "--processed_bucket"            = $BUCKET_PROCESSED
    "--database_name"               = $GLUE_DB
    "--table_name"                  = $TABLE_NAME
} | ConvertTo-Json -Compress

$defaultArgsFile = "$env:TEMP\glue-job-args.json"
$defaultArgs | Out-File -FilePath $defaultArgsFile -Encoding UTF8

aws glue create-job `
    --name $JOB_NAME `
    --description "Sales data ETL: CSV raw → Parquet processed with enrichment" `
    --role $ROLE_ARN `
    --command "{`"Name`":`"glueetl`",`"ScriptLocation`":`"$SCRIPT_S3`",`"PythonVersion`":`"3`"}" `
    --default-arguments file://$defaultArgsFile `
    --glue-version "4.0" `
    --worker-type "G.1X" `
    --number-of-workers 2 `
    --timeout 20 `
    --max-retries 1 `
    --tags "{`"Project`":`"SalesETL`",`"Environment`":`"Dev`"}" `
    --region $AWS_REGION | Out-Null

Write-Host "  Job created: $JOB_NAME" -ForegroundColor Green
Write-Host "  Worker: G.1X x 2 workers (free tier: ~0.5 DPU-hr per run)" -ForegroundColor DarkGreen
Write-Host "  Glue version: 4.0 (Spark 3.3)" -ForegroundColor DarkGreen

# --------------------------------------------------------------------------
# START THE JOB RUN
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[2/3] Starting job run..." -ForegroundColor Yellow

$jobRunResult = aws glue start-job-run `
    --job-name $JOB_NAME `
    --region $AWS_REGION `
    --output json | ConvertFrom-Json

$JOB_RUN_ID = $jobRunResult.JobRunId
Write-Host "  Job Run ID: $JOB_RUN_ID" -ForegroundColor Green

# --------------------------------------------------------------------------
# POLL JOB STATUS WITH LIVE FEEDBACK
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[3/3] Monitoring job execution..." -ForegroundColor Yellow
Write-Host "  (Glue jobs take 3-8 minutes to start and run)"
Write-Host ""

$attempts   = 0
$maxAttempts= 60
$finalState = ""

do {
    Start-Sleep -Seconds 20
    $attempts++

    $runInfo = aws glue get-job-run `
        --job-name $JOB_NAME `
        --run-id $JOB_RUN_ID `
        --region $AWS_REGION `
        --output json | ConvertFrom-Json

    $state   = $runInfo.JobRun.JobRunState
    $message = $runInfo.JobRun.ErrorMessage

    $elapsed = $attempts * 20
    $minutes = [Math]::Floor($elapsed / 60)
    $seconds = $elapsed % 60

    $stateColor = switch ($state) {
        "RUNNING"   { "DarkYellow" }
        "SUCCEEDED" { "Green" }
        "FAILED"    { "Red" }
        "STOPPED"   { "Yellow" }
        default     { "White" }
    }

    Write-Host "  [$($minutes)m$($seconds)s] State: $state" -ForegroundColor $stateColor

    if ($state -in @("SUCCEEDED", "FAILED", "STOPPED", "ERROR", "TIMEOUT")) {
        $finalState = $state
        break
    }
} while ($attempts -lt $maxAttempts)

# --------------------------------------------------------------------------
# RESULTS
# --------------------------------------------------------------------------
Write-Host ""
if ($finalState -eq "SUCCEEDED") {
    $run = $runInfo.JobRun
    Write-Host "================================================" -ForegroundColor Green
    Write-Host "  ETL Job SUCCEEDED" -ForegroundColor Green
    Write-Host "================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "  DPU-hours consumed : $($run.DPUSeconds / 3600)"
    Write-Host "  Execution time     : $($run.ExecutionTime) seconds"
    Write-Host "  Max capacity       : $($run.MaxCapacity) DPUs"
    Write-Host ""
    Write-Host "  Processed output   : s3://$BUCKET_PROCESSED/sales/"
    Write-Host ""

    # Show output files
    Write-Host "  Output files:"
    aws s3 ls "s3://$BUCKET_PROCESSED/sales/" --recursive --human-readable | ForEach-Object {
        Write-Host "    $_" -ForegroundColor DarkGreen
    }

} elseif ($finalState -eq "FAILED") {
    Write-Host "================================================" -ForegroundColor Red
    Write-Host "  ETL Job FAILED" -ForegroundColor Red
    Write-Host "================================================" -ForegroundColor Red
    Write-Host "  Error: $($runInfo.JobRun.ErrorMessage)" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Debug steps:"
    Write-Host "  1. Check CloudWatch logs:"
    Write-Host "     aws logs tail /aws-glue/jobs/output --follow --region $AWS_REGION"
    Write-Host "  2. View job run details:"
    Write-Host "     aws glue get-job-run --job-name $JOB_NAME --run-id $JOB_RUN_ID --region $AWS_REGION"
} else {
    Write-Warning "Job ended with state: $finalState"
}

Write-Host ""
Write-Host "Next step: Run  .\05_setup_athena_and_query.ps1"
Write-Host ""

# Save job run ID for reference
$config | Add-Member -NotePropertyName "LAST_JOB_RUN_ID" -NotePropertyValue $JOB_RUN_ID -Force
$config | ConvertTo-Json | Out-File -FilePath ".\project-config.json" -Encoding UTF8
