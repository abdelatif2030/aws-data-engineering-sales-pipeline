# =============================================================================
# AWS Glue Sales ETL Project - Step 1: Infrastructure Setup
# Compatible with: AWS Free Tier | PowerShell 5.1+ | AWS CLI v2
# =============================================================================
# Run this first. Sets up: S3 buckets, IAM role, Glue database, CloudWatch log group.
# =============================================================================

# --------------------------------------------------------------------------
# CONFIGURATION - Edit these values before running
# --------------------------------------------------------------------------
$AWS_REGION      = "us-east-1"          # Free tier region (best coverage)
$ACCOUNT_ID      = "YOUR_ACCOUNT_ID"    # 12-digit AWS account ID
$PROJECT_NAME    = "sales-etl"
$UNIQUE_SUFFIX   = "$(Get-Random -Maximum 9999)"  # Keeps bucket names globally unique

# Derived names (no changes needed below)
$BUCKET_RAW      = "$PROJECT_NAME-raw-$UNIQUE_SUFFIX"
$BUCKET_PROCESSED= "$PROJECT_NAME-processed-$UNIQUE_SUFFIX"
$BUCKET_SCRIPTS  = "$PROJECT_NAME-scripts-$UNIQUE_SUFFIX"
$BUCKET_ATHENA   = "$PROJECT_NAME-athena-$UNIQUE_SUFFIX"
$GLUE_DB         = "sales_db"
$GLUE_ROLE       = "GlueSalesETLRole"
$LOG_GROUP       = "/aws-glue/jobs/sales-etl"

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  AWS Glue Sales ETL - Infrastructure Setup" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Region  : $AWS_REGION"
Write-Host "Raw S3  : $BUCKET_RAW"
Write-Host "Scripts : $BUCKET_SCRIPTS"
Write-Host ""

# --------------------------------------------------------------------------
# PREREQUISITE CHECK
# --------------------------------------------------------------------------
Write-Host "[CHECK] Verifying AWS CLI installation..." -ForegroundColor Yellow
try {
    $awsVersion = aws --version 2>&1
    Write-Host "  AWS CLI: $awsVersion" -ForegroundColor Green
} catch {
    Write-Error "AWS CLI not found. Install from: https://aws.amazon.com/cli/"
    exit 1
}

Write-Host "[CHECK] Verifying AWS credentials..." -ForegroundColor Yellow
$identity = aws sts get-caller-identity --output json 2>&1 | ConvertFrom-Json
if ($LASTEXITCODE -ne 0) {
    Write-Error "No valid AWS credentials. Run: aws configure"
    exit 1
}
Write-Host "  Account : $($identity.Account)" -ForegroundColor Green
Write-Host "  UserArn : $($identity.Arn)" -ForegroundColor Green
$ACCOUNT_ID = $identity.Account

# --------------------------------------------------------------------------
# STEP 1: CREATE S3 BUCKETS
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[1/5] Creating S3 Buckets..." -ForegroundColor Yellow

$buckets = @($BUCKET_RAW, $BUCKET_PROCESSED, $BUCKET_SCRIPTS, $BUCKET_ATHENA)
foreach ($bucket in $buckets) {
    Write-Host "  Creating: $bucket"
    if ($AWS_REGION -eq "us-east-1") {
        aws s3api create-bucket --bucket $bucket --region $AWS_REGION | Out-Null
    } else {
        aws s3api create-bucket --bucket $bucket --region $AWS_REGION `
            --create-bucket-configuration LocationConstraint=$AWS_REGION | Out-Null
    }

    # Block all public access (security best practice)
    aws s3api put-public-access-block --bucket $bucket `
        --public-access-block-configuration `
        "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true" | Out-Null

    # Enable versioning on raw bucket
    if ($bucket -eq $BUCKET_RAW) {
        aws s3api put-bucket-versioning --bucket $bucket `
            --versioning-configuration Status=Enabled | Out-Null
        Write-Host "    Versioning enabled on raw bucket" -ForegroundColor DarkGreen
    }

    Write-Host "    Created: s3://$bucket" -ForegroundColor Green
}

# Create S3 folder structure
Write-Host "  Creating folder structure..."
"" | aws s3 cp - "s3://$BUCKET_RAW/sales/year=2024/month=01/.keep" | Out-Null
"" | aws s3 cp - "s3://$BUCKET_PROCESSED/sales/.keep" | Out-Null
"" | aws s3 cp - "s3://$BUCKET_SCRIPTS/glue-scripts/.keep" | Out-Null
"" | aws s3 cp - "s3://$BUCKET_ATHENA/results/.keep" | Out-Null

# --------------------------------------------------------------------------
# STEP 2: CREATE IAM ROLE FOR GLUE
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[2/5] Creating IAM Role for AWS Glue..." -ForegroundColor Yellow

$trustPolicy = @{
    Version   = "2012-10-17"
    Statement = @(@{
        Effect    = "Allow"
        Principal = @{ Service = "glue.amazonaws.com" }
        Action    = "sts:AssumeRole"
    })
} | ConvertTo-Json -Depth 5

$trustPolicyFile = "$env:TEMP\glue-trust-policy.json"
$trustPolicy | Out-File -FilePath $trustPolicyFile -Encoding UTF8

aws iam create-role `
    --role-name $GLUE_ROLE `
    --assume-role-policy-document file://$trustPolicyFile `
    --description "IAM role for Glue Sales ETL jobs" | Out-Null

# Attach AWS managed Glue service policy
aws iam attach-role-policy `
    --role-name $GLUE_ROLE `
    --policy-arn "arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole" | Out-Null

# Attach CloudWatch full access for job logging
aws iam attach-role-policy `
    --role-name $GLUE_ROLE `
    --policy-arn "arn:aws:iam::aws:policy/CloudWatchLogsFullAccess" | Out-Null

# Create inline S3 policy for project buckets only (least privilege)
$s3Policy = @{
    Version   = "2012-10-17"
    Statement = @(
        @{
            Effect   = "Allow"
            Action   = @("s3:GetObject","s3:PutObject","s3:DeleteObject","s3:ListBucket")
            Resource = @(
                "arn:aws:s3:::$BUCKET_RAW",
                "arn:aws:s3:::$BUCKET_RAW/*",
                "arn:aws:s3:::$BUCKET_PROCESSED",
                "arn:aws:s3:::$BUCKET_PROCESSED/*",
                "arn:aws:s3:::$BUCKET_SCRIPTS",
                "arn:aws:s3:::$BUCKET_SCRIPTS/*"
            )
        },
        @{
            Effect   = "Allow"
            Action   = @("glue:GetTable","glue:GetDatabase","glue:UpdateTable","glue:CreatePartition","glue:BatchCreatePartition")
            Resource = "*"
        }
    )
} | ConvertTo-Json -Depth 6

$s3PolicyFile = "$env:TEMP\glue-s3-policy.json"
$s3Policy | Out-File -FilePath $s3PolicyFile -Encoding UTF8

aws iam put-role-policy `
    --role-name $GLUE_ROLE `
    --policy-name "GlueSalesS3Access" `
    --policy-document file://$s3PolicyFile | Out-Null

$ROLE_ARN = "arn:aws:iam::${ACCOUNT_ID}:role/$GLUE_ROLE"
Write-Host "  Role ARN: $ROLE_ARN" -ForegroundColor Green

# --------------------------------------------------------------------------
# STEP 3: CREATE GLUE DATA CATALOG DATABASE
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[3/5] Creating Glue Data Catalog Database..." -ForegroundColor Yellow

aws glue create-database `
    --database-input "{`"Name`":`"$GLUE_DB`",`"Description`":`"Sales analytics ETL database`",`"LocationUri`":`"s3://$BUCKET_PROCESSED/`"}" `
    --region $AWS_REGION | Out-Null

Write-Host "  Database created: $GLUE_DB" -ForegroundColor Green

# --------------------------------------------------------------------------
# STEP 4: CREATE CLOUDWATCH LOG GROUP
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[4/5] Creating CloudWatch Log Group..." -ForegroundColor Yellow

aws logs create-log-group --log-group-name $LOG_GROUP --region $AWS_REGION 2>&1 | Out-Null
aws logs put-retention-policy `
    --log-group-name $LOG_GROUP `
    --retention-in-days 7 `
    --region $AWS_REGION | Out-Null

Write-Host "  Log group: $LOG_GROUP (7-day retention)" -ForegroundColor Green

# --------------------------------------------------------------------------
# STEP 5: SAVE CONFIG FILE for subsequent scripts
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[5/5] Saving project configuration..." -ForegroundColor Yellow

$config = @{
    AWS_REGION       = $AWS_REGION
    ACCOUNT_ID       = $ACCOUNT_ID
    BUCKET_RAW       = $BUCKET_RAW
    BUCKET_PROCESSED = $BUCKET_PROCESSED
    BUCKET_SCRIPTS   = $BUCKET_SCRIPTS
    BUCKET_ATHENA    = $BUCKET_ATHENA
    GLUE_DB          = $GLUE_DB
    GLUE_ROLE        = $GLUE_ROLE
    ROLE_ARN         = $ROLE_ARN
    LOG_GROUP        = $LOG_GROUP
    CREATED_AT       = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
}

$config | ConvertTo-Json | Out-File -FilePath ".\project-config.json" -Encoding UTF8
Write-Host "  Config saved: .\project-config.json" -ForegroundColor Green

# --------------------------------------------------------------------------
# SUMMARY
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "================================================" -ForegroundColor Green
Write-Host "  Infrastructure Setup COMPLETE" -ForegroundColor Green
Write-Host "================================================" -ForegroundColor Green
Write-Host ""
Write-Host "Next step: Run  .\02_upload_data_and_scripts.ps1"
Write-Host ""
Write-Host "S3 Buckets created:" -ForegroundColor Cyan
Write-Host "  Raw data  : s3://$BUCKET_RAW"
Write-Host "  Processed : s3://$BUCKET_PROCESSED"
Write-Host "  Scripts   : s3://$BUCKET_SCRIPTS"
Write-Host "  Athena    : s3://$BUCKET_ATHENA"
Write-Host ""
Write-Host "IMPORTANT - Free Tier Tips:" -ForegroundColor Yellow
Write-Host "  - Glue: 40 DPU-hours/month free (first year)"
Write-Host "  - Use G.1X worker type to minimize DPU consumption"
Write-Host "  - Delete resources after practice to avoid charges"
Write-Host ""
