# =============================================================================
# AWS Glue Sales ETL Project - Step 3: Create & Run Glue Crawler
# =============================================================================
# Creates a Glue Crawler that inspects S3 data and populates the Data Catalog.
# The crawler detects CSV schema and Hive-style partitions automatically.
# Run after: 02_upload_data_and_scripts.ps1
# =============================================================================

$config      = Get-Content ".\project-config.json" | ConvertFrom-Json
$BUCKET_RAW  = $config.BUCKET_RAW
$GLUE_DB     = $config.GLUE_DB
$ROLE_ARN    = $config.ROLE_ARN
$AWS_REGION  = $config.AWS_REGION
$CRAWLER     = "sales_raw_crawler"

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Step 3: Create & Run Glue Crawler" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan

# --------------------------------------------------------------------------
# CREATE THE CRAWLER
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[1/3] Creating Glue Crawler: $CRAWLER ..." -ForegroundColor Yellow

# Check if crawler already exists
$existingCrawler = aws glue get-crawler --name $CRAWLER --region $AWS_REGION 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "  Crawler already exists, skipping creation." -ForegroundColor Yellow
} else {
    aws glue create-crawler `
        --name $CRAWLER `
        --role $ROLE_ARN `
        --database-name $GLUE_DB `
        --description "Crawls raw sales CSV data and infers schema" `
        --targets "{`"S3Targets`":[{`"Path`":`"s3://$BUCKET_RAW/sales/`",`"Exclusions`":[`"**/.keep`"]}]}" `
        --schema-change-policy "{`"UpdateBehavior`":`"UPDATE_IN_DATABASE`",`"DeleteBehavior`":`"LOG`"}" `
        --recrawl-policy "{`"RecrawlBehavior`":`"CRAWL_EVERYTHING`"}" `
        --configuration "{`"Version`":1.0,`"CrawlerOutput`":{`"Partitions`":{`"AddOrUpdateBehavior`":`"InheritFromTable`"},`"Tables`":{`"AddOrUpdateBehavior`":`"MergeNewColumns`"}},`"Grouping`":{`"TableGroupingPolicy`":`"CombineCompatibleSchemas`"}}" `
        --region $AWS_REGION | Out-Null

    Write-Host "  Crawler created: $CRAWLER" -ForegroundColor Green
    Write-Host "  Target: s3://$BUCKET_RAW/sales/" -ForegroundColor DarkGreen
    Write-Host "  Database: $GLUE_DB" -ForegroundColor DarkGreen
}

# --------------------------------------------------------------------------
# RUN THE CRAWLER
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[2/3] Starting crawler run..." -ForegroundColor Yellow

aws glue start-crawler --name $CRAWLER --region $AWS_REGION | Out-Null
Write-Host "  Crawler started. Polling for completion (this takes ~1-2 minutes)..."

# Poll until crawler finishes
$attempts = 0
$maxAttempts = 30
do {
    Start-Sleep -Seconds 10
    $attempts++
    $crawlerInfo = aws glue get-crawler --name $CRAWLER --region $AWS_REGION --output json | ConvertFrom-Json
    $state = $crawlerInfo.Crawler.State
    Write-Host "  [$($attempts * 10)s] Crawler state: $state" -ForegroundColor DarkYellow
} while ($state -eq "RUNNING" -and $attempts -lt $maxAttempts)

if ($state -eq "READY") {
    $lastRun = $crawlerInfo.Crawler.LastCrawl
    Write-Host "  Crawler finished. Status: $($lastRun.Status)" -ForegroundColor Green
    Write-Host "  Tables created: $($lastRun.TablesCreated)" -ForegroundColor Green
    Write-Host "  Tables updated: $($lastRun.TablesUpdated)" -ForegroundColor Green
    Write-Host "  Duration: $($lastRun.DurationSeconds)s" -ForegroundColor DarkGreen
} else {
    Write-Warning "  Crawler did not finish in expected time. Current state: $state"
}

# --------------------------------------------------------------------------
# INSPECT DISCOVERED TABLES
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[3/3] Inspecting discovered catalog tables..." -ForegroundColor Yellow

$tables = aws glue get-tables --database-name $GLUE_DB --region $AWS_REGION --output json | ConvertFrom-Json
foreach ($table in $tables.TableList) {
    Write-Host "  Table: $($table.Name)" -ForegroundColor Green
    Write-Host "    Location : $($table.StorageDescriptor.Location)"
    Write-Host "    Format   : $($table.StorageDescriptor.InputFormat)"
    Write-Host "    Columns  : $($table.StorageDescriptor.Columns.Count)"
    Write-Host "    Partitions:"
    foreach ($pk in $table.PartitionKeys) {
        Write-Host "      - $($pk.Name) ($($pk.Type))"
    }
}

Write-Host ""
Write-Host "================================================" -ForegroundColor Green
Write-Host "  Crawler COMPLETE - Schema Cataloged" -ForegroundColor Green
Write-Host "================================================" -ForegroundColor Green
Write-Host "Next step: Run  .\04_create_glue_job.ps1"
Write-Host ""
