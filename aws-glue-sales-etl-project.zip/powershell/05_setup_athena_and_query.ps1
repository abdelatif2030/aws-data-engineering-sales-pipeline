# =============================================================================
# AWS Glue Sales ETL Project - Step 5: Athena Setup & Analytics Queries
# =============================================================================
# Creates Athena workgroup, crawls processed Parquet, and runs 5 analytics
# queries to validate the ETL output.
# Run after: 04_create_glue_job.ps1
# =============================================================================

$config          = Get-Content ".\project-config.json" | ConvertFrom-Json
$BUCKET_PROCESSED= $config.BUCKET_PROCESSED
$BUCKET_ATHENA   = $config.BUCKET_ATHENA
$ROLE_ARN        = $config.ROLE_ARN
$GLUE_DB         = $config.GLUE_DB
$AWS_REGION      = $config.AWS_REGION

$WORKGROUP       = "sales-etl-workgroup"
$CRAWLER_OUT     = "sales_processed_crawler"

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Step 5: Athena Analytics on ETL Output" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan

# --------------------------------------------------------------------------
# FUNCTION: Run Athena query and wait for results
# --------------------------------------------------------------------------
function Invoke-AthenaQuery {
    param(
        [string]$QueryString,
        [string]$QueryDescription = "Query"
    )

    $execResult = aws athena start-query-execution `
        --query-string $QueryString `
        --work-group $WORKGROUP `
        --query-execution-context "Database=$GLUE_DB" `
        --region $AWS_REGION `
        --output json | ConvertFrom-Json

    $execId = $execResult.QueryExecutionId

    # Poll until done
    do {
        Start-Sleep -Seconds 3
        $status = aws athena get-query-execution `
            --query-execution-id $execId `
            --region $AWS_REGION `
            --output json | ConvertFrom-Json
        $state = $status.QueryExecution.Status.State
    } while ($state -in @("RUNNING", "QUEUED"))

    if ($state -eq "SUCCEEDED") {
        $dataScanned = $status.QueryExecution.Statistics.DataScannedInBytes
        $execTime    = $status.QueryExecution.Statistics.EngineExecutionTimeInMillis
        Write-Host "    Athena: $QueryDescription" -ForegroundColor DarkGreen
        Write-Host "      Data scanned: $([Math]::Round($dataScanned/1KB, 2)) KB | Time: $($execTime)ms"

        # Fetch results
        $results = aws athena get-query-results `
            --query-execution-id $execId `
            --region $AWS_REGION `
            --output json | ConvertFrom-Json

        return $results.ResultSet.Rows
    } else {
        $reason = $status.QueryExecution.Status.StateChangeReason
        Write-Warning "    Query FAILED: $reason"
        return $null
    }
}

# --------------------------------------------------------------------------
# STEP 1: Create Athena Workgroup with cost controls
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[1/4] Creating Athena Workgroup..." -ForegroundColor Yellow

$wgCheck = aws athena get-work-group --work-group $WORKGROUP --region $AWS_REGION 2>&1
if ($LASTEXITCODE -ne 0) {
    aws athena create-work-group `
        --name $WORKGROUP `
        --configuration "{
          `"ResultConfiguration`":{
            `"OutputLocation`":`"s3://$BUCKET_ATHENA/results/`",
            `"EncryptionConfiguration`":{`"EncryptionOption`":`"SSE_S3`"}
          },
          `"BytesScannedCutoffPerQuery`":104857600,
          `"EnforceWorkGroupConfiguration`":true,
          `"PublishCloudWatchMetricsEnabled`":true
        }" `
        --description "Workgroup for Sales ETL analytics" `
        --region $AWS_REGION | Out-Null

    Write-Host "  Workgroup created: $WORKGROUP" -ForegroundColor Green
    Write-Host "  Cost guard: queries capped at 100MB data scan" -ForegroundColor DarkGreen
} else {
    Write-Host "  Workgroup exists: $WORKGROUP" -ForegroundColor DarkGreen
}

# --------------------------------------------------------------------------
# STEP 2: Crawl Processed Parquet to register in Catalog
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[2/4] Crawling processed Parquet data..." -ForegroundColor Yellow

$crawlerCheck = aws glue get-crawler --name $CRAWLER_OUT --region $AWS_REGION 2>&1
if ($LASTEXITCODE -ne 0) {
    aws glue create-crawler `
        --name $CRAWLER_OUT `
        --role $ROLE_ARN `
        --database-name $GLUE_DB `
        --description "Crawls processed Parquet sales data" `
        --targets "{`"S3Targets`":[{`"Path`":`"s3://$BUCKET_PROCESSED/sales/`"}]}" `
        --region $AWS_REGION | Out-Null
}

aws glue start-crawler --name $CRAWLER_OUT --region $AWS_REGION | Out-Null
Write-Host "  Crawler started, waiting..."
do {
    Start-Sleep -Seconds 10
    $cr = aws glue get-crawler --name $CRAWLER_OUT --region $AWS_REGION --output json | ConvertFrom-Json
} while ($cr.Crawler.State -eq "RUNNING")
Write-Host "  Parquet schema registered in catalog" -ForegroundColor Green

# --------------------------------------------------------------------------
# STEP 3: Run 5 Analytics Queries
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[3/4] Running Analytics Queries on Processed Data..." -ForegroundColor Yellow
Write-Host ""

# --- Query 1: Revenue summary by category ---
Write-Host "  Query 1: Revenue by Category" -ForegroundColor Cyan
$q1 = "SELECT category, COUNT(*) AS total_orders, SUM(net_revenue) AS total_revenue, ROUND(AVG(gross_margin_pct)*100,1) AS avg_margin_pct FROM sales ORDER BY total_revenue DESC"
$r1 = Invoke-AthenaQuery -QueryString $q1 -QueryDescription "Revenue by Category"
if ($r1) {
    $r1 | Select-Object -Skip 1 | ForEach-Object {
        $vals = $_.Data.VarCharValue
        Write-Host ("      {0,-15} {1,8} orders   {2,10} revenue   {3,6}% margin" -f $vals[0],$vals[1],$vals[2],$vals[3]) -ForegroundColor White
    }
}
Write-Host ""

# --- Query 2: Top salesperson by revenue ---
Write-Host "  Query 2: Top Salespersons" -ForegroundColor Cyan
$q2 = "SELECT salesperson, COUNT(*) AS deals, SUM(net_revenue) AS revenue, SUM(gross_profit) AS profit FROM sales GROUP BY salesperson ORDER BY revenue DESC LIMIT 5"
$r2 = Invoke-AthenaQuery -QueryString $q2 -QueryDescription "Top Salespersons"
if ($r2) {
    $r2 | Select-Object -Skip 1 | ForEach-Object {
        $vals = $_.Data.VarCharValue
        Write-Host ("      {0,-20} {1,5} deals   {2,10} revenue" -f $vals[0],$vals[1],$vals[2]) -ForegroundColor White
    }
}
Write-Host ""

# --- Query 3: Monthly revenue trend ---
Write-Host "  Query 3: Monthly Revenue Trend" -ForegroundColor Cyan
$q3 = "SELECT order_year, order_month, COUNT(*) AS orders, SUM(net_revenue) AS revenue FROM sales GROUP BY order_year, order_month ORDER BY order_year, order_month"
$r3 = Invoke-AthenaQuery -QueryString $q3 -QueryDescription "Monthly Trend"
if ($r3) {
    $r3 | Select-Object -Skip 1 | ForEach-Object {
        $vals = $_.Data.VarCharValue
        Write-Host ("      {0}-{1:D2}   {2,5} orders   {3,10} revenue" -f $vals[0],$vals[1],$vals[2],$vals[3]) -ForegroundColor White
    }
}
Write-Host ""

# --- Query 4: Discount impact analysis ---
Write-Host "  Query 4: Discount Impact" -ForegroundColor Cyan
$q4 = "SELECT is_discounted, COUNT(*) AS orders, ROUND(AVG(discount_pct),1) AS avg_discount_pct, SUM(discount_amount) AS total_discounts_given, SUM(net_revenue) AS revenue FROM sales GROUP BY is_discounted"
$r4 = Invoke-AthenaQuery -QueryString $q4 -QueryDescription "Discount Impact"
if ($r4) {
    $r4 | Select-Object -Skip 1 | ForEach-Object {
        $vals = $_.Data.VarCharValue
        Write-Host ("      Discounted={0}  orders={1}  avg_disc={2}%  discounts_given={3}" -f $vals[0],$vals[1],$vals[2],$vals[3]) -ForegroundColor White
    }
}
Write-Host ""

# --- Query 5: Revenue tier distribution ---
Write-Host "  Query 5: Revenue Tier Breakdown" -ForegroundColor Cyan
$q5 = "SELECT revenue_tier, COUNT(*) AS orders, SUM(net_revenue) AS revenue, ROUND(COUNT(*)*100.0/SUM(COUNT(*)) OVER(), 1) AS pct_of_orders FROM sales GROUP BY revenue_tier ORDER BY revenue DESC"
$r5 = Invoke-AthenaQuery -QueryString $q5 -QueryDescription "Revenue Tiers"
if ($r5) {
    $r5 | Select-Object -Skip 1 | ForEach-Object {
        $vals = $_.Data.VarCharValue
        Write-Host ("      {0,-8}  {1,5} orders ({2}%)  {3,10} revenue" -f $vals[0],$vals[1],$vals[3],$vals[2]) -ForegroundColor White
    }
}

# --------------------------------------------------------------------------
# STEP 4: Cost Summary
# --------------------------------------------------------------------------
Write-Host ""
Write-Host "[4/4] Free Tier Usage Summary..." -ForegroundColor Yellow
Write-Host "  Glue Crawler runs: ~2 DPU-hours used"
Write-Host "  Glue ETL job: ~0.5 DPU-hours per run"
Write-Host "  Athena queries: minimal data scanned (Parquet is efficient)"
Write-Host "  S3: < 1MB data stored"
Write-Host ""

Write-Host "================================================" -ForegroundColor Green
Write-Host "  Analytics Setup COMPLETE" -ForegroundColor Green
Write-Host "================================================" -ForegroundColor Green
Write-Host "Next step: Run  .\06_create_workflow.ps1 (orchestration)"
Write-Host "   OR     Run  .\07_cleanup.ps1 (tear down all resources)"
Write-Host ""
